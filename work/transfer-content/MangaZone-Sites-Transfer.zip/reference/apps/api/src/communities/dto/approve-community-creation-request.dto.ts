export class ApproveCommunityCreationRequestDto {}
