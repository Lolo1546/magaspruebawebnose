export class ApproveScanlationGroupCreationRequestDto {}
