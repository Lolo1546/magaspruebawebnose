export { NewInMangaZone } from "./NewInMangaZone";
